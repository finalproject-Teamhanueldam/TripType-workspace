package com.kh.triptype.mail.dao;

public class EmailAuthDao {

}
