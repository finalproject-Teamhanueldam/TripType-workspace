package com.kh.triptype.mail.controller;

public class EmailAuthController {

}
