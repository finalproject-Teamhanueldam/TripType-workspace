package com.kh.triptype.mail.model.vo;

public class EmailAuth {

}
