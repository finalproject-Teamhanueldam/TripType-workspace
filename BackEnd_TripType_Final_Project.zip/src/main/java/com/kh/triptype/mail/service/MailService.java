package com.kh.triptype.mail.service;

public class MailService {

}
