package com.kh.triptype.mypage.dao;

public class MyPageDao {

}
