package com.kh.triptype.mypage.service;

public class MyPageServiceImpl {

}
