package com.kh.triptype.mypage.controller;

public class MyPageController {

}
