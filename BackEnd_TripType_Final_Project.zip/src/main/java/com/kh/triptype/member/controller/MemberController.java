package com.kh.triptype.member.controller;

public class MemberController {

}
