package com.kh.triptype.member.service;

public class MemberService {

}
