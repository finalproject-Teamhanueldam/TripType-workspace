package com.kh.triptype.member.model.vo;

public class Member {

}
