package com.kh.triptype.member.dao;

public class MemberDao {

}
