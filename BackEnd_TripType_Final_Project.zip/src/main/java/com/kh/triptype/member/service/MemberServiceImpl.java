package com.kh.triptype.member.service;

public interface MemberServiceImpl {

}
