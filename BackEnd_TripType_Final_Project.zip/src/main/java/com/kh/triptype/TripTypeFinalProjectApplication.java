package com.kh.triptype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripTypeFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripTypeFinalProjectApplication.class, args);
	}

}
