package com.kh.triptype.admin.member.service;

public class AdminMemberService {

}
