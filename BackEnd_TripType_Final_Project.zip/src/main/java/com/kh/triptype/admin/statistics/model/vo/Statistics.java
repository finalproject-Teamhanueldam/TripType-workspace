package com.kh.triptype.admin.statistics.model.vo;

public class Statistics {

}
