package com.kh.triptype.admin.flight.controller;

public class AdminFlightController {

}
