package com.kh.triptype.admin.member.dao;

public class AdminMemberDao {

}
