package com.kh.triptype.admin.member.controller;

public class AdmintMemberController {

}
