package com.kh.triptype.admin.flight.service;

public class AdminFlightServiceImp {

}
