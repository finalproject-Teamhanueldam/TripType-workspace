package com.kh.triptype.admin.statistics.service;

public class StatisticsServiceIml {

}
