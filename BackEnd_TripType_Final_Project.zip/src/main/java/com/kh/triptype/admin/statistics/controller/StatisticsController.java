package com.kh.triptype.admin.statistics.controller;

public class StatisticsController {

}
