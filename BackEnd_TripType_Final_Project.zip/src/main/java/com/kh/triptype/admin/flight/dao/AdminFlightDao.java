package com.kh.triptype.admin.flight.dao;

public class AdminFlightDao {

}
