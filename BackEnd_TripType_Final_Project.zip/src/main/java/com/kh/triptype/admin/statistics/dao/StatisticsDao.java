package com.kh.triptype.admin.statistics.dao;

public class StatisticsDao {

}
