package com.kh.triptype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripTypeFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
